// Remove top border from first membership card

var memberships = document.getElementsByClassName("membership");
var first = memberships[0];
first.classList.add("no-top-border");